-- phpMyAdmin SQL Dump
-- version 4.2.7
-- http://www.phpmyadmin.net
--
-- Host: localhost:3306
-- Generation Time: Apr 30, 2016 at 11:04 PM
-- Server version: 5.5.41-log
-- PHP Version: 7.0.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `inf3005demo`
--

-- --------------------------------------------------------

--
-- Table structure for table `age`
--

CREATE TABLE IF NOT EXISTS `age` (
`id` int(11) NOT NULL,
  `min` int(11) NOT NULL,
  `max` int(11) NOT NULL,
  `points` int(11) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `age`
--

INSERT INTO `age` (`id`, `min`, `max`, `points`) VALUES
(1, 18, 35, 16),
(2, 36, 36, 14),
(3, 37, 37, 12),
(4, 38, 38, 10),
(5, 39, 39, 8),
(6, 40, 40, 6),
(7, 41, 41, 4),
(8, 42, 42, 2),
(9, 43, 120, 0);

-- --------------------------------------------------------

--
-- Table structure for table `candidats`
--

CREATE TABLE IF NOT EXISTS `candidats` (
`idcand` int(11) NOT NULL,
  `nom` varchar(25) NOT NULL,
  `prenom` varchar(25) NOT NULL,
  `datedenaissance` date NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `candidats`
--

INSERT INTO `candidats` (`idcand`, `nom`, `prenom`, `datedenaissance`) VALUES
(1, 'Francise', 'Pierre', '2000-12-24'),
(2, 'Meaurois', 'Isabelle', '1999-03-03'),
(3, 'ff', 'tt', '1990-10-10'),
(4, 'ss', 'aaa', '1999-12-01'),
(5, 'Aaa', 'Bbbb', '1988-10-01'),
(6, 'Mim', 'Lol', '1982-02-03');

-- --------------------------------------------------------

--
-- Table structure for table `consultants`
--

CREATE TABLE IF NOT EXISTS `consultants` (
`idcons` int(11) NOT NULL,
  `nom` varchar(25) NOT NULL,
  `prenom` varchar(25) NOT NULL,
  `compagnie` varchar(40) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `consultants`
--

INSERT INTO `consultants` (`idcons`, `nom`, `prenom`, `compagnie`) VALUES
(1, 'Lol', 'Juil', 'ASSS');

-- --------------------------------------------------------

--
-- Table structure for table `demandes`
--

CREATE TABLE IF NOT EXISTS `demandes` (
`iddem` int(11) NOT NULL,
  `idcand` int(11) NOT NULL,
  `datedemande` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `idcons` int(11) DEFAULT NULL,
  `pointscand` int(11) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `demandes`
--

INSERT INTO `demandes` (`iddem`, `idcand`, `datedemande`, `idcons`, `pointscand`) VALUES
(1, 2, '2016-04-27 21:48:37', NULL, 31),
(2, 2, '2016-04-27 21:59:56', NULL, 50),
(3, 4, '2016-04-27 04:00:00', NULL, 45),
(4, 3, '2016-04-27 22:30:55', NULL, 60),
(5, 6, '2016-04-29 14:51:46', NULL, 55),
(6, 6, '2016-04-30 22:54:12', 1, 56);

-- --------------------------------------------------------

--
-- Table structure for table `domaine_formation`
--

CREATE TABLE IF NOT EXISTS `domaine_formation` (
`id` int(11) NOT NULL,
  `domaine` varchar(50) NOT NULL,
  `points` int(11) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `domaine_formation`
--

INSERT INTO `domaine_formation` (`id`, `domaine`, `points`) VALUES
(1, 'technique informatique', 10),
(2, 'techniqie electrique', 10),
(3, 'biologique', 20),
(4, 'chimie', 15),
(5, 'linguistique', 10),
(6, 'juridique', 8),
(7, 'comptabilite', 8),
(8, 'phinanciere', 8);

-- --------------------------------------------------------

--
-- Table structure for table `epreuve`
--

CREATE TABLE IF NOT EXISTS `epreuve` (
  `epreuve` varchar(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `epreuve`
--

INSERT INTO `epreuve` (`epreuve`) VALUES
('CE'),
('CO'),
('EE'),
('EO');

-- --------------------------------------------------------

--
-- Table structure for table `niveau_scolarite`
--

CREATE TABLE IF NOT EXISTS `niveau_scolarite` (
`id` int(11) NOT NULL,
  `niveau` varchar(150) NOT NULL,
  `points` int(11) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=12 ;

--
-- Dumping data for table `niveau_scolarite`
--

INSERT INTO `niveau_scolarite` (`id`, `niveau`, `points`) VALUES
(1, 'Secondaire général', 2),
(2, 'Secondaire professionnel', 6),
(3, 'Postsecondaire général 2 ans', 4),
(4, 'Postsecondaire technique 1 an ou 2 ans', 6),
(5, 'Secondaire professionnel 1 an ou +', 0),
(6, 'Postsecondaire thechnique 3 ans', 8),
(7, 'Univercitaire 1er cycle 1 an', 4),
(8, 'Universitaire 1er cycle 2 ans', 6),
(9, 'Universitaire 1er cycle 3 ans ou +', 10),
(10, 'Universitaire 2ième cycle 1 an ou +', 12),
(11, 'Universitaire 3ième cycle', 14);

-- --------------------------------------------------------

--
-- Table structure for table `resultat_epreuve`
--

CREATE TABLE IF NOT EXISTS `resultat_epreuve` (
  `resultat` varchar(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `resultat_epreuve`
--

INSERT INTO `resultat_epreuve` (`resultat`) VALUES
('A1'),
('A2'),
('B1'),
('B2'),
('C1'),
('C2');

-- --------------------------------------------------------

--
-- Table structure for table `seuils`
--

CREATE TABLE IF NOT EXISTS `seuils` (
`id` int(11) NOT NULL,
  `points` int(11) NOT NULL,
  `datevalidite` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=21 ;

--
-- Dumping data for table `seuils`
--

INSERT INTO `seuils` (`id`, `points`, `datevalidite`) VALUES
(1, 11, '2016-04-29 17:02:49'),
(2, 22, '2016-04-29 17:08:33'),
(3, 33, '2016-04-29 19:04:41'),
(4, 44, '2016-04-25 16:09:50'),
(5, 50, '2016-04-25 16:10:48'),
(14, 38, '2016-04-29 22:26:44'),
(15, 64, '2016-04-29 22:28:47'),
(16, 57, '2016-04-29 22:29:18'),
(17, 66, '2016-04-29 22:34:09'),
(19, 88, '2016-04-29 23:05:47'),
(20, 49, '2016-04-29 23:43:02');

-- --------------------------------------------------------

--
-- Table structure for table `tef`
--

CREATE TABLE IF NOT EXISTS `tef` (
  `epreuve` varchar(2) NOT NULL,
  `resultat` varchar(2) NOT NULL,
  `points` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tef`
--

INSERT INTO `tef` (`epreuve`, `resultat`, `points`) VALUES
('CE', 'A1', 0),
('CO', 'A1', 0),
('EE', 'A1', 0),
('EO', 'A1', 0),
('CE', 'A2', 0),
('CO', 'A2', 0),
('EE', 'A2', 0),
('EO', 'A2', 0),
('CE', 'B1', 0),
('CO', 'B1', 0),
('EE', 'B1', 0),
('EO', 'B1', 0),
('CE', 'B2', 5),
('CO', 'B2', 5),
('EE', 'B2', 5),
('EO', 'B2', 5),
('CE', 'C1', 6),
('CO', 'C1', 6),
('EE', 'C1', 6),
('EO', 'C1', 6),
('CE', 'C2', 7),
('CO', 'C2', 7),
('EE', 'C2', 7),
('EO', 'C2', 7);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `age`
--
ALTER TABLE `age`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `candidats`
--
ALTER TABLE `candidats`
 ADD PRIMARY KEY (`idcand`);

--
-- Indexes for table `consultants`
--
ALTER TABLE `consultants`
 ADD PRIMARY KEY (`idcons`);

--
-- Indexes for table `demandes`
--
ALTER TABLE `demandes`
 ADD PRIMARY KEY (`iddem`);

--
-- Indexes for table `domaine_formation`
--
ALTER TABLE `domaine_formation`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `epreuve`
--
ALTER TABLE `epreuve`
 ADD UNIQUE KEY `epreuve` (`epreuve`);

--
-- Indexes for table `niveau_scolarite`
--
ALTER TABLE `niveau_scolarite`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `resultat_epreuve`
--
ALTER TABLE `resultat_epreuve`
 ADD UNIQUE KEY `resultat` (`resultat`);

--
-- Indexes for table `seuils`
--
ALTER TABLE `seuils`
 ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `points` (`points`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `age`
--
ALTER TABLE `age`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `candidats`
--
ALTER TABLE `candidats`
MODIFY `idcand` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `consultants`
--
ALTER TABLE `consultants`
MODIFY `idcons` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `demandes`
--
ALTER TABLE `demandes`
MODIFY `iddem` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `domaine_formation`
--
ALTER TABLE `domaine_formation`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `niveau_scolarite`
--
ALTER TABLE `niveau_scolarite`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `seuils`
--
ALTER TABLE `seuils`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=21;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
